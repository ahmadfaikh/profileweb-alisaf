import {
  EducationUnit,
  SantriSchedule,
  Facility,
  NewsItem,
  Achievement,
  FaqItem,
  Educator,
  MediaItem
} from '../types/pesantren';

export const PESANTREN_INFO = {
  name: "Pondok Pesantren Al Is'af",
  arabicName: "مَعْهَدُ الْإِسْعَافِ الإِسْلَامِيّ",
  tagline: "Madrasah Diniyah Takmiliyah, MTs Al-Roudloh & MA Ibnu Hajar",
  motto: "Al-Muhafadzatu 'alal qadimis shalih, wal akhdzu bil jadidil ashlah",
  mottoTranslation: "Memelihara tradisi lama yang baik, dan mengambil inovasi baru yang lebih baik",
  foundedYear: 2017,
  founder: "KH. Agus Mujahiddin, S.Pd.I",
  currentLeader: "KH. Agus Mujahiddin, S.Pd.I",
  address: "Ds. Sidodadi, Kec. Sukosewu, Kab. Bojonegoro, Jawa Timur 62185",
  phone: "0851 3805 8390",
  whatsapp: "0851 3805 8390",
  whatsappDigits: "6285138058390",
  email: "pompesalisaf2017@gmail.com",
  nspp: "510035220088", // Nomor Statistik Pondok Pesantren Bojonegoro
  psbGoogleFormUrl: "https://docs.google.com/forms", // URL Google Form Pendaftaran Santri Baru
  stats: {
    santriCount: "450+",
    asatidzCount: "32+",
    educationUnits: "3",
    alumniCount: "380+",
    huffazhCount: "95+"
  }
};

export const PANCA_JIWA = [
  {
    title: "Keikhlasan",
    arabic: "الإِخْلَاص",
    desc: "Mendasari setiap tarikan nafas belajar, beribadah, dan mengabdi semata-mata mengharap ridha Allah SWT, tanpa pamrih keduniawian.",
    icon: "Heart"
  },
  {
    title: "Kesederhanaan",
    arabic: "البَسَاطَة",
    desc: "Bukan berarti miskin atau melarat, melainkan jiwa yang bersahaja, wajar, bersyukur, serta berjiwa besar dalam menghadapi segala tantangan.",
    icon: "Compass"
  },
  {
    title: "Kemandirian (Berdikari)",
    arabic: "الاعْتِمَادُ عَلَى النَّفْس",
    desc: "Santri dididik sanggup mengurus keperluan diri sendiri, bertanggung jawab atas amanah, serta kelak menjadi pionir mandiri di masyarakat.",
    icon: "ShieldCheck"
  },
  {
    title: "Ukhuwah Islamiyah",
    arabic: "الأُخُوَّةُ الإِسْلَامِيَّة",
    desc: "Tali persaudaraan yang erat tanpa membedakan suku, kedaerahan, ataupun status sosial, bersatu dalam bingkai santri Ahlussunnah wal Jama'ah.",
    icon: "Users"
  },
  {
    title: "Kebebasan Berfikir",
    arabic: "حُرِّيَّةُ التَّفْكِير",
    desc: "Berfikir kritis, berwawasan luas, terbuka terhadap ilmu pengetahuan modern, dengan tetap berpegang teguh pada tuntunan syariat Islam.",
    icon: "Sparkles"
  }
];

export const EDUCATION_UNITS: EducationUnit[] = [
  {
    id: "madin",
    name: "Madrasah Diniyah Takmiliyah",
    arabicName: "المَدْرَسَةُ الدِّينِيَّة التَّكْمِيلِيَّة",
    category: "diniyah",
    level: "Ula - Wustho - Ulya",
    description: "Pendidikan keagamaan Islam non-formal berjenjang yang memfokuskan pengkajian ilmu-ilmu keislaman, gramatika bahasa Arab (nahwu & shorof), dan kitab salafiyah.",
    curriculum: [
      "Nahwu & Shorof (Jurumiyyah, Imrithi, Alfiyah Ibnu Malik)",
      "Fiqh & Ushul Fiqh (Safinatun Najah, Fathul Qorib, Fathul Mu'in)",
      "Hadits (Arba'in Nawawiyyah, Bulughul Maram, Shahih Bukhari)",
      "Tauhid & Tasawuf (Aqidatul Awam, Tijan Darori, Ihya Ulumiddin)"
    ],
    features: ["Sorogan & Bandongan", "Lailatul Munadzarah (Bahtsul Masa'il)", "Sanad Keilmuan Mu'tabar", "Pengajian Kilatan Ramadhan"],
    headmaster: "Ust. H. M. Zainul Muttaqin, Lc., M.H.",
    iconName: "BookOpen"
  },
  {
    id: "mts",
    name: "MTs Al-Roudloh",
    arabicName: "المَدْرَسَةُ الثَّانَوِيَّة الرَّوْضَة",
    category: "formal",
    level: "Madrasah Tsanawiyah (Setingkat SMP)",
    description: "Pendidikan menengah pertama formal yang memadukan kurikulum pendidikan madrasah dengan nilai-nilai kepesantrenan, pembiasaan karakter disiplin, dan penguatan keilmuan.",
    curriculum: [
      "Kurikulum Pendidikan Madrasah (IPA, Matematika, IPS, Bahasa)",
      "Integrasi Kurikulum Pesantren (Bahasa Arab, PAI Plus)",
      "Bimbingan Kompetisi Sains Madrasah (KSM)",
      "Program Pembiasaan Sholat Berjamaah & Tahsin Al-Qur'an"
    ],
    features: ["Laboratorium IPA & Komputer", "Kelas Minat Bakat", "Pembinaan Karakter 24 Jam", "Kaderisasi Santri Terampil"],
    headmaster: "Drs. KH. Mas'ud Hasan, M.Pd.",
    iconName: "GraduationCap"
  },
  {
    id: "ma",
    name: "MA Ibnu Hajar",
    arabicName: "مَدْرَسَةُ ابْنِ حَجَر العَالِيَة",
    category: "formal",
    level: "Madrasah Aliyah (Setingkat SMA)",
    description: "Pendidikan menengah atas formal yang berorientasi mencetak kader-kader religius, terampil, dan berakhlakul karimah yang siap bersaing serta berkhidmah bagi ummat.",
    curriculum: [
      "Kurikulum Pendidikan Madrasah Aliyah Lengkap",
      "Penguatan Turats Salaf & Bahasa Internasional (Arab & Inggris)",
      "Keterampilan Terapan & Literasi Digital",
      "Bimbingan Studi Lanjut Perguruan Tinggi & Kepemimpinan"
    ],
    features: ["Kaderisasi Ulama & Intelektual", "Bimbingan Masuk Perguruan Tinggi", "Pengembangan Bakat & Kewirausahaan", "Organisasi & Kepemimpinan Santri"],
    headmaster: "Ustadz M. Ridwan, S.Pd.I",
    iconName: "Award"
  }
];

export const SANTRI_DAILY_SCHEDULE: SantriSchedule[] = [
  {
    time: "03.30 - 04.30",
    activity: "Bangun Pagi & Qiyamul Lail",
    arabicTitle: "قِيَامُ اللَّيْلِ وَالتَّهَجُّد",
    description: "Bangun lebih awal untuk sholat tahajjud, witir, muhasabah, dan persiapan sholat Subuh berjamaah di Masjid Jami'.",
    category: "ibadah",
    location: "Masjid Jami' Al Is'af"
  },
  {
    time: "04.30 - 05.30",
    activity: "Sholat Subuh & Wirid Rotib",
    arabicTitle: "صَلَاةُ الصُّبْحِ وَالأَوْرَاد",
    description: "Sholat Subuh berjamaah diimami pengasuh, dilanjutkan pembacaan Ratibul Haddad dan wirid ma'tsurat.",
    category: "ibadah",
    location: "Masjid Jami'"
  },
  {
    time: "05.30 - 06.30",
    activity: "Kajian Kitab Kuning Pagi / Ziyadah Tahfizh",
    arabicTitle: "قِرَاءَةُ التُّرَاثِ وَالتَّحْفِيظ",
    description: "Halaqah pengajian kitab tafsir & hadits bersama Masyayikh, serta setoran hafalan baru bagi santri tahfizh.",
    category: "diniyah",
    location: "Serambi Masjid & Halaqah Asrama"
  },
  {
    time: "06.30 - 07.15",
    activity: "Sarapan Pagi & Persiapan Sekolah",
    arabicTitle: "الفُطُورُ وَالتَّهَيُّؤُ لِلدِّرَاسَة",
    description: "Makan pagi bersama di asrama, piket kebersihan lingkungan kamar, dan mengenakan seragam sekolah.",
    category: "kemandirian",
    location: "Dapur Asrama & Kompleks Santri"
  },
  {
    time: "07.15 - 12.30",
    activity: "Kegiatan Belajar Formal (MTs / MA / SMK)",
    arabicTitle: "الدِّرَاسَةُ النِّظَامِيَّة",
    description: "Mengikuti proses belajar mengajar kurikulum nasional dan kurikulum madrasah di gedung kelas masing-masing.",
    category: "formal",
    location: "Gedung Madrasah & Lab"
  },
  {
    time: "12.30 - 13.30",
    activity: "Sholat Dzuhur Berjamaah & Makan Siang",
    arabicTitle: "صَلَاةُ الظُّهْرِ وَالغَدَاء",
    description: "Sholat Dzuhur berjamaah, makan siang bersama, dan istirahat sejenak (Qailulah).",
    category: "ibadah",
    location: "Masjid & Ruang Makan"
  },
  {
    time: "13.30 - 15.00",
    activity: "Madrasah Diniyah (Madin) Siang",
    arabicTitle: "المَدْرَسَةُ الدِّينِيَّة",
    description: "Kajian ilmu nahwu, shorof, fiqih aplikatif, tarikh islam, dan tajwid terstruktur berjenjang.",
    category: "diniyah",
    location: "Ruang Kelas Diniyah"
  },
  {
    time: "15.00 - 16.00",
    activity: "Sholat Ashar & Dzikir Petang",
    arabicTitle: "صَلَاةُ العَصْرِ وَالأَذْكَار",
    description: "Sholat Ashar berjamaah dilanjutkan membaca surah Al-Waqi'ah bersama.",
    category: "ibadah",
    location: "Masjid Jami'"
  },
  {
    time: "16.00 - 17.15",
    activity: "Ekstrakurikuler, Olahraga & Mandi Sore",
    arabicTitle: "الرِّيَاضَةُ وَالأَنْشِطَةُ الإِضَافِيَّة",
    description: "Pilihan kegiatan santri: Hadrah Banjari, Kaligrafi, Pramuka, Futsal, Silat Pagar Nusa, Panahan, dan kebersihan diri.",
    category: "kemandirian",
    location: "Lapangan Pesantren & Aula"
  },
  {
    time: "17.30 - 19.30",
    activity: "Sholat Maghrib & Sorogan Kitab Masyayikh",
    arabicTitle: "صَلَاةُ المَغْرِبِ وَحَلَقَاتُ التُّرَاث",
    description: "Membaca Al-Qur'an menjelang Maghrib, sholat Maghrib berjamaah, dilanjutkan pengajian wetonan kitab besar oleh Pengasuh.",
    category: "diniyah",
    location: "Masjid Jami' Al Is'af"
  },
  {
    time: "19.30 - 20.30",
    activity: "Sholat Isya Berjamaah & Makan Malam",
    arabicTitle: "صَلَاةُ العِشَاءِ وَالعَشَاء",
    description: "Sholat Isya berjamaah, pengumuman bahasa harian, dan makan malam santri.",
    category: "ibadah",
    location: "Masjid & Asrama"
  },
  {
    time: "20.30 - 22.00",
    activity: "Belajar Mandiri Terpimpin & Musyawarah Fiqh",
    arabicTitle: "المُذَاكَرَةُ المُوَجَّهَةُ وَالمُشَاوَرَة",
    description: "Muthala'ah pelajaran madrasah, menghafal nazham imrithi/alfiyah, dan diskusi Bahtsul Masa'il didampingi ustadz wali kamar.",
    category: "formal",
    location: "Kamar Asrama & Gazebo Ma'had"
  },
  {
    time: "22.00 - 03.30",
    activity: "Istirahat Malam (Tidur Nyenyak)",
    arabicTitle: "النَّوْمُ وَالرَّاحَة",
    description: "Memadamkan lampu kamar, membaca doa tidur, dan beristirahat mengumpulkan energi untuk ibadah esok hari.",
    category: "istirahat",
    location: "Kamar Santri Putra / Putri"
  }
];

export const FACILITIES: Facility[] = [
  {
    id: "musholla",
    name: "Musholla",
    category: "ibadah",
    description: "Sarana ibadah sholat berjamaah lima waktu, halaqah Al-Qur'an, dan kajian kitab kuning para santri.",
    features: [],
    image: "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1000&q=80"
  },
  {
    id: "asrama-putra",
    name: "Kompleks Asrama Putra",
    category: "asrama",
    description: "Fasilitas tempat tinggal santri putra yang bersih, tertib, dan kondusif untuk pembiasaan adab kemandirian.",
    features: [],
    image: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80"
  },
  {
    id: "asrama-putri",
    name: "Komplek Asrama Putri",
    category: "asrama",
    description: "Kawasan hunian santri putri dengan keamanan terjaga dan pembinaan khusus asatidzah.",
    features: [],
    image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1000&q=80"
  },
  {
    id: "gedung-pembelajaran",
    name: "Gedung Pembelajaran",
    category: "akademik",
    description: "Ruang kelas kegiatan belajar mengajar santri yang nyaman, terang, dan representatif.",
    features: [],
    image: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=1000&q=80"
  },
  {
    id: "ruang-santai",
    name: "Ruang Santai",
    category: "penunjang",
    description: "Area santai dan membaca santri di sela-sela jadwal kegiatan ibadah dan sekolah.",
    features: [],
    image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1000&q=80"
  },
  {
    id: "koperasi",
    name: "Koperasi",
    category: "penunjang",
    description: "Penyedia kebutuhan harian santri, kitab-kitab pesantren, alat tulis, dan perlengkapan asrama.",
    features: [],
    image: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1000&q=80"
  }
];

export const ACHIEVEMENTS: Achievement[] = [];

export const NEWS_ITEMS: NewsItem[] = [
  {
    id: "news-1",
    title: "Penerimaan Santri Baru (PSB) Tahun Ajaran 2026/2027 Resmi Dibuka",
    date: "12 Maret 2026",
    category: "Warta Pesantren",
    excerpt: "Pondok Pesantren Al Is'af kembali membuka pendaftaran santri baru untuk jenjang Salafiyah, Tahfizhul Qur'an, MTs, dan persiapan SMK secara daring dan luring.",
    author: "Panitia PSB Al Is'af",
    readTime: "3 menit baca",
    image: "https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "news-2",
    title: "Haflah Akhirussanah & Khotmil Qur'an Berlangsung Khidmat",
    date: "28 Februari 2026",
    category: "Warta Pesantren",
    excerpt: "Santri berhasil mengkhatamkan Al-Qur'an 30 Juz dan santri menamatkan kajian kitab kuning dasar dihadapan wali santri.",
    author: "Humas Pesantren",
    readTime: "4 menit baca",
    image: "https://images.unsplash.com/photo-1609599006353-e629aaabfeae?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "news-3",
    title: "Santri Al Is'af Raih Prestasi Gemilang di MQK Cabang Fathul Qorib",
    date: "15 Januari 2026",
    category: "Prestasi",
    excerpt: "Ketekunan mengkaji kitab kuning mengantarkan santri Al Is'af meraih podium juara Musabaqah Qira'atil Kutub.",
    author: "Redaksi Pesantren",
    readTime: "3 menit baca",
    image: "https://images.unsplash.com/photo-1532012164546-f432f2e3777a?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "news-4",
    title: "Tausiyah Pengasuh KH. Agus Mujahiddin, S.Pd.I: Menjaga Adab Menuntut Ilmu",
    date: "05 Januari 2026",
    category: "Tausiyah",
    excerpt: "KH. Agus Mujahiddin, S.Pd.I berpesan bahwa santri harus istiqomah dalam mengaji kitab salaf, menghafal Al-Qur'an, dan berakhlak mulia.",
    author: "Dewan Asatidz",
    readTime: "5 menit baca",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80"
  }
];

export const FAQ_LIST: FaqItem[] = [
  {
    id: "faq-1",
    question: "Kapan periode pendaftaran santri baru (PSB) dibuka dan bagaimana jalurnya?",
    answer: "Pendaftaran dibuka dalam 2 Gelombang: Gelombang 1 (Januari - April) dan Gelombang 2 (Mei - Juli). Pendaftaran dapat dilakukan secara online melalui website ini dengan mengisi formulir registrasi, atau langsung datang ke sekretariat PSB di kantor pondok pesantren Ds. Sidodadi, Sukosewu, Bojonegoro.",
    category: "psb"
  },
  {
    id: "faq-2",
    question: "Apakah santri diwajibkan tinggal di asrama (mukim)?",
    answer: "Ya, seluruh santri diwajibkan mukim (tinggal di dalam asrama pesantren). Hal ini bertujuan untuk memaksimalkan pembinaan akhlak, pengajian kitab kuning, dan ibadah berjamaah 24 jam.",
    category: "keseharian"
  },
  {
    id: "faq-3",
    question: "Berapa rincian perkiraan biaya masuk awal dan SPP bulanan?",
    answer: "Biaya masuk awal meliputi uang pangkal/sarana gedung, seragam resmi (3 stel), kasur & perlengkapan kamar, serta kitab panduan awal berkisar antara Rp 3.200.000 - Rp 3.900.000 (hanya dibayar 1x saat diterima). Iuran bulanan terpadu (SPP sekolah, biaya pondok, dan makan 3x sehari) berkisar Rp 650.000 - Rp 750.000/bulan.",
    category: "biaya"
  },
  {
    id: "faq-4",
    question: "Apakah tersedia beasiswa bagi santri tahfizh atau keluarga kurang mampu?",
    answer: "Tersedia beasiswa santri berprestasi, beasiswa tahfizh (potongan SPP 50% - 100% bagi yang hafal mutqin), serta Program Santri Asuh untuk yatim piatu dan dhuafa.",
    category: "biaya"
  },
  {
    id: "faq-5",
    question: "Kapan jadwal kunjungan/sambangan orang tua dan aturan membawa alat elektronik?",
    answer: "Waktu kunjungan/sambangan wali santri adalah setiap hari Ahad (Minggu) pekan ke-2 dan ke-4 setiap bulannya. Demi kekhusyukan belajar, santri tidak diperkenankan membawa HP/gadget pribadi; komunikasi dengan wali santri difasilitasi melalui kontak sekretariat pesantren & wali asrama.",
    category: "keseharian"
  },
  {
    id: "faq-6",
    question: "Apa saja ijazah yang akan diperoleh santri setelah lulus?",
    answer: "Santri akan memperoleh: (1) Ijazah Formal sesuai jenjang (MTs Al-Roudloh / MA Ibnu Hajar); (2) Ijazah Madrasah Diniyah Takmiliyah Pondok Pesantren Al Is'af; dan (3) Syahadah Tahfizhul Qur'an (bagi santri tahfizh).",
    category: "akademik"
  }
];

export const PSB_COST_BREAKDOWN = {
  registrationFee: 150000,
  levels: [
    {
      id: "mts",
      name: "MTs Al Is'af (Tsanawiyah)",
      baseUangPangkal: 2800000,
      uniformBooks: 950000,
      monthlyFee: 700000, // SPP + Pondok + Makan 3x/hari
      desc: "Termasuk kasur asrama, lemari, seragam 3 stel, dan paket kitab Diniyah dasar."
    },
    {
      id: "smk",
      name: "SMK Al Is'af (Persiapan Vokasi/TKJ/DKV)",
      baseUangPangkal: 3200000,
      uniformBooks: 1100000,
      monthlyFee: 750000,
      desc: "Termasuk modul keterampilan vokasi, seragam praktik, dan fasilitas asrama santri."
    },
    {
      id: "tahfizh-salaf",
      name: "LTQ (Tahfizh) & Salafiyah Murni",
      baseUangPangkal: 2400000,
      uniformBooks: 850000,
      monthlyFee: 650000,
      desc: "Khusus santri fokus menghafal Al-Qur'an 30 Juz dan ngaji kitab kuning tanpa sekolah formal."
    }
  ]
};

export const EDUCATORS: Educator[] = [
  {
    id: "kh-agus-mujahiddin",
    name: "KH. Agus Mujahiddin, S.Pd.I",
    arabicTitle: "مُؤَسِّسُ المَعْهَدِ وَخَادِمُهُ",
    role: "Pendiri & Pengasuh Pondok Pesantren Al Is'af",
    category: "masyayikh",
    expertise: ["Kajian Turats Salaf", "Tahfizhul Qur'an", "Pendidikan Agama Islam", "Tarbiyatul Akhlak"],
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80",
    education: "Pondok Pesantren Salaf & Sarjana Pendidikan Islam (S.Pd.I)",
    bio: "Pendiri sekaligus Pengasuh Pondok Pesantren Al Is'af yang mendirikan pondok pada tahun 2017 di Ds. Sidodadi, Kec. Sukosewu, Kab. Bojonegoro. Beliau mencurahkan khidmah membina para santri berfokus pada pengajian kitab kuning salafiyah dan tahfizhul Qur'an, mengembangkan madrasah formal jenjang MTs, serta kini memimpin proses pembangunan kampus SMK Al Is'af.",
    experienceYears: 18,
    taughtSubjects: ["Kajian Kitab Salaf", "Tahfizh Al-Qur'an", "Tafsir Jalalain", "Fathul Qorib"]
  },
  {
    id: "ust-abdul-muid",
    name: "Ustadz H. Abdul Mu'id Al-Hafizh",
    arabicTitle: "رَئِيسُ مَعْهَدِ تَحْفِيظِ القُرْآن",
    role: "Kepala Program Tahfidzul Qur'an",
    category: "tahfizh",
    expertise: ["Tahfizh 30 Juz Mutqin", "Qira'ah Sab'ah", "Matan Al-Jazariyyah", "Seni Tilawah"],
    photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=800&q=80",
    education: "Pondok Tahfizh Kudus & Jam'iyyatul Qurra' Wal Huffazh",
    bio: "Hafizhul Qur'an bersanad yang mendedikasikan hidupnya membimbing para santri menghafal Al-Qur'an dengan metode talaqqi musyafahah. Telah meluluskan lebih dari 320 wisudawan 30 juz mutqin.",
    experienceYears: 18,
    taughtSubjects: ["Ziyadah & Takrir 30 Juz", "Matan Jazariyyah", "Tajwid Gharib & Fashahah"]
  },
  {
    id: "ust-zainul-muttaqin",
    name: "Ustadz H. M. Zainul Muttaqin, Lc., M.H.",
    arabicTitle: "مُدِيرُ المَدْرَسَةِ الدِّينِيَّة",
    role: "Kepala Madrasah Diniyah Ta'miliyah",
    category: "diniyah",
    expertise: ["Gramatika Arab (Nahwu-Shorof)", "Balaghah & Arudh", "Fiqih Syafi'i", "'Ilmul Mantiq"],
    photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=800&q=80",
    education: "S1 Syari'ah Islamiyyah Universitas Al-Azhar Kairo, Mesir & S2 Hukum Islam",
    bio: "Pakar turats klasik lulusan Kairo yang membina kajian nahwu shorof tingkat lanjut (Alfiyah Ibnu Malik) dan Bahtsul Masa'il. Mendidik santri agar mahir membaca, memahami, dan membedah kitab gundul secara mandiri.",
    experienceYears: 16,
    taughtSubjects: ["Alfiyah Ibnu Malik", "Fathul Qorib", "Jauharul Maknun (Balaghah)"]
  },
  {
    id: "nyai-nur-azizah",
    name: "Nyai Hj. Siti Nur Azizah, S.Ag., M.Pd.",
    arabicTitle: "مُرَبِّيَةُ الطَّالِبَات",
    role: "Pengasuh Asrama Putri & Pembina Santriwati",
    category: "asatidzah",
    expertise: ["Tarbiyatul Mar'ah", "Fiqih Kewanitaan (Fiqh Nisa')", "Akhlaq Tasawuf", "Tahsin Al-Qur'an"],
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80",
    education: "UIN Sunan Ampel Surabaya & Pascasarjana Manajemen Pendidikan Islam",
    bio: "Ibu Nyai pengasuh komplek keputrian yang dengan penuh keibuan membimbing ketertiban adab, kebersihan, kemandirian santriwati, serta kajian khusus hukum fiqih wanita dan kitab Risalatul Mahidh.",
    experienceYears: 20,
    taughtSubjects: ["Risalatul Mahidh", "Akhlaq Lil Banat", "Bidayatul Hidayah"]
  },
  {
    id: "drs-masud-hasan",
    name: "Drs. KH. Mas'ud Hasan, M.Pd.",
    arabicTitle: "رَئِيسُ المَدْرَسَةِ الثَّانَوِيَّة",
    role: "Kepala MTs Al Is'af",
    category: "formal",
    expertise: ["Manajemen Pendidikan Madrasah", "Ilmu Falak & Hisab Astronomi", "Pendidikan Karakter"],
    photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=800&q=80",
    education: "IAIN Sunan Kalijaga & Universitas Negeri Malang",
    bio: "Pendidik senior yang telah memimpin MTs Al Is'af meraih status Akreditasi A (Unggul) secara berturut-turut. Aktif membina santri dalam tim Kompetisi Sains Madrasah (KSM) dan keilmuan hisab rukyat.",
    experienceYears: 25,
    taughtSubjects: ["Bahasa Arab Formal", "Sejarah Kebudayaan Islam", "Ilmu Falak"]
  },
  {
    id: "ust-m-ridwan",
    name: "Ustadz M. Ridwan, S.Pd.I",
    arabicTitle: "وَكِيلُ شُؤُونِ المَنَاهِجِ",
    role: "Waka Kurikulum MTs Al Is'af",
    category: "formal",
    expertise: ["Pengembangan Kurikulum Madrasah", "Fiqih & Ushul Fiqih", "Bimbingan Prestasi KSM"],
    photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80",
    education: "S1 Pendidikan Agama Islam UIN Sunan Ampel Surabaya",
    bio: "Berpengalaman dalam integrasi kurikulum Kemenag dengan muatan lokal kepesantrenan. Membina para santri MTs Al Is'af agar unggul dalam bidang akademik sains madrasah dan keagamaan.",
    experienceYears: 15,
    taughtSubjects: ["Fiqih Madrasah", "Ke-NU-an / Aswaja", "Pembinaan KSM"]
  },
  {
    id: "ir-shodiq",
    name: "Ir. Muhammad Shodiq, S.T., M.Kom.",
    arabicTitle: "رَئِيسُ لَجْنَةِ تَطْوِيرِ المَدْرَسَةِ المِهْنِيَّة",
    role: "Ketua Tim Pengembang & Sarana SMK Al Is'af",
    category: "formal",
    expertise: ["Jaringan Komputer & Fiber Optic", "Rekayasa Perangkat Lunak", "Perencanaan Sarana Vokasi", "Technopreneur"],
    photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80",
    education: "S1 Teknik Elektro ITS Surabaya & S2 Ilmu Komputer UI",
    bio: "Praktisi teknologi informasi yang memimpin persiapan dan pembangunan fasilitas kejuruan SMK Al Is'af, memastikan sarana laboratorium komputer dan kurikulum vokasi selaras dengan kebutuhan industri modern.",
    experienceYears: 14,
    taughtSubjects: ["Pengenalan Teknologi Informasi", "Dasar Pemrograman", "Kewirausahaan Santri"]
  },
  {
    id: "ustazah-wardatul-jannah",
    name: "Ustadzah Wardatul Jannah, S.Pd.I., Al-Hafizhah",
    arabicTitle: "مُشْرِفَةُ التَّحْفِيظِ لِلطَّالِبَات",
    role: "Koordinator Tahfizh Putri",
    category: "asatidzah",
    expertise: ["Tahfizh 30 Juz Bersanad", "Naghom Tilawah Al-Qur'an", "Tajwid Tuhfatul Athfal"],
    photo: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=800&q=80",
    education: "Institut Ilmu Al-Qur'an (IIQ) Jakarta",
    bio: "Hafizhah 30 juz berprestasi nasional yang membina halaqah tahfizh santriwati dengan metode talaqqi penuh kesabaran, memperhatikan makhraj dan tartil bernada Bayati, Shoba, dan Hijaz.",
    experienceYears: 12,
    taughtSubjects: ["Tahfizh Putri 30 Juz", "Matan Tuhfatul Athfal", "Bimbingan Naghom Tilawah"]
  },
  {
    id: "ust-ahmad-faruq",
    name: "Ustadz Ahmad Faruq, M.Pd.",
    arabicTitle: "مُشْرِفُ مَهَارَاتِ الخِطَابَةِ وَاللُّغَة",
    role: "Pembina Khitobah & Bahasa Santri",
    category: "diniyah",
    expertise: ["Bahasa Arab Komunikatif", "Public Speaking / Muhadharah", "Khitobah 3 Bahasa"],
    photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=800&q=80",
    education: "S1 & S2 Pendidikan Bahasa Arab UIN",
    bio: "Membina kegiatan muhadharah (latihan pidato) mingguan santri dalam bahasa Arab dan Indonesia, melatih mental santri berdakwah di mimbar masyarakat.",
    experienceYears: 11,
    taughtSubjects: ["Muhadatsah / Bahasa Arab", "Muhadharah & Khitobah", "Insya' / Menulis Arab"]
  }
];

export const MEDIA_GALLERY: MediaItem[] = [
  {
    id: "media-v1",
    type: "video",
    title: "Profil Dokumenter Pondok Pesantren Al Is'af",
    category: "acara",
    categoryLabel: "Video Profil Ma'had",
    thumbnail: "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1200&q=80",
    videoEmbedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // fallback player or iframe
    duration: "08:45 Menit",
    date: "Januari 2026",
    description: "Dokumentasi komprehensif kehidupan santri, kurikulum salafiyah dan Al-Qur'an, pendidikan formal MTs, serta progres pembangunan gedung SMK di Pondok Pesantren Al Is'af Sidodadi, Sukosewu, Bojonegoro."
  },
  {
    id: "media-v2",
    type: "video",
    title: "Haflah Khotmil Qur'an & Wisuda Sanad 30 Juz Ke-42",
    category: "acara",
    categoryLabel: "Prosesi Wisuda Akbar",
    thumbnail: "https://images.unsplash.com/photo-1609599006353-e629aaabfeae?auto=format&fit=crop&w=1200&q=80",
    videoEmbedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    duration: "14:20 Menit",
    date: "Februari 2026",
    description: "Momen khidmat dan haru saat 75 santri putra dan putri menerima syahadah sanad Al-Qur'an 30 juz langsung dihadapan Masyayikh dan ribuan wali santri."
  },
  {
    id: "media-v3",
    type: "video",
    title: "Festival Seni Sholawat & Hadrah Banjari Santri",
    category: "kegiatan",
    categoryLabel: "Seni Budaya Santri",
    thumbnail: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80",
    videoEmbedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    duration: "06:35 Menit",
    date: "November 2025",
    description: "Penampilan memukau grup rebana dan hadrah Al Is'af membawakan lantunan sholawat thibbil qulub dalam rangka peringatan Maulid Nabi Muhammad SAW."
  },
  {
    id: "media-p1",
    type: "photo",
    title: "Pengajian Sorogan & Bandongan Kitab Kuning",
    category: "kegiatan",
    categoryLabel: "Kajian Turats Salafiyah",
    thumbnail: "https://images.unsplash.com/photo-1532012164546-f432f2e3777a?auto=format&fit=crop&w=1000&q=80",
    date: "Harian Ba'da Subuh",
    description: "Santri dengan khusyuk memaknai kitab Fathul Qorib dan Alfiyah Ibnu Malik dengan tulisan pegon pego bersanding langsung dengan para Asatidz senior."
  },
  {
    id: "media-p2",
    type: "photo",
    title: "Halaqah Tahfizhul Qur'an Talaqqi Musyafahah",
    category: "kegiatan",
    categoryLabel: "Tahfizh 30 Juz",
    thumbnail: "https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1000&q=80",
    date: "Harian 05.30 - 06.30 WIB",
    description: "Santri menyetorkan hafalan baru (ziyadah) dan mengulang hafalan lama (takrir) di hadapan ustadz pembimbing halaqah di serambi Masjid Jami'."
  },
  {
    id: "media-p3",
    type: "photo",
    title: "Masjid Jami' Al Is'af Pusat Ibadah 2.500 Santri",
    category: "fasilitas",
    categoryLabel: "Fasilitas Ibadah",
    thumbnail: "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1000&q=80",
    date: "Arsitektur Megah",
    description: "Arsitektur kubah hijau yang meneduhkan, marmer alami, dan tata suara akustik yang menunjang sholat lima waktu berjamaah secara berjamaah tepat waktu."
  },
  {
    id: "media-p4",
    type: "photo",
    title: "Kawasan Asrama Santri Tertata Bersih & Asri",
    category: "fasilitas",
    categoryLabel: "Hunian Asrama Santri",
    thumbnail: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1000&q=80",
    date: "Kompleks Asrama",
    description: "Lingkungan asrama bertingkat dengan ventilasi udara segar, loker pribadi, dan pengawasan wali kamar 24 jam demi kenyamanan dan kedisiplinan santri."
  },
  {
    id: "media-p5",
    type: "photo",
    title: "Laboratorium Komputer & Jaringan Berkecepatan Tinggi",
    category: "fasilitas",
    categoryLabel: "Sarana Akademik IT",
    thumbnail: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=1000&q=80",
    date: "Praktek SMK & Ujian CBT",
    description: "Didukung 80 unit PC berkinerja tinggi dan koneksi fiber optic untuk pembelajaran coding, mikrotik, desain multimedia, dan ujian berbasis komputer."
  },
  {
    id: "media-p6",
    type: "photo",
    title: "Maktabah & Koleksi Kitab Turats Klasik",
    category: "fasilitas",
    categoryLabel: "Perpustakaan & Riset",
    thumbnail: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1000&q=80",
    date: "Maktabah Al Is'af",
    description: "Koleksi lebih dari 15.000 judul kitab fiqih, tafsir mu'tabar, naskah klasik, serta literatur sains kontemporer sebagai referensi bahtsul masa'il."
  },
  {
    id: "media-p7",
    type: "photo",
    title: "Upacara Peringatan Hari Santri Nasional",
    category: "acara",
    categoryLabel: "Peringatan Hari Besar",
    thumbnail: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1000&q=80",
    date: "22 Oktober",
    description: "Ribuan santri berbusana sarung dan kopyah putih khidmat mengikuti apel Hari Santri Nasional memperingati Resolusi Jihad para ulama dan pejuang bangsa."
  },
  {
    id: "media-p8",
    type: "photo",
    title: "Latihan Memanah (Archery) Olahraga Sunnah",
    category: "kegiatan",
    categoryLabel: "Ekstrakurikuler Sunnah",
    thumbnail: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=1000&q=80",
    date: "Pekan Olahraga Santri",
    description: "Melatih ketangkasan, fokus, dan ketenangan jiwa melalui olahraga memanah sesuai anjuran Rasulullah SAW di lapangan terbuka pesantren."
  },
  {
    id: "media-p9",
    type: "photo",
    title: "Pelantikan Pengurus Organisasi Santri Pesantren (OSPA)",
    category: "acara",
    categoryLabel: "Kepemimpinan Santri",
    thumbnail: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1000&q=80",
    date: "Awal Tahun Ajaran",
    description: "Prosesi serah terima amanah kepengurusan organisasi santri, menumbuhkan jiwa kepemimpinan mandiri, manajerial, dan tanggung jawab sosial."
  }
];

